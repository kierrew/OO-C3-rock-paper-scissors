package Model.idemo;

public interface ISound {

	String getSound();
	
}
