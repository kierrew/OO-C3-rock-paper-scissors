package Model.Shapes;
import java.awt.Graphics2D;

public interface IShapesDraw {

	void render(Graphics2D g2);
	
}
